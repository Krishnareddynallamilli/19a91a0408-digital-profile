Thanks for downloading this template!

Template Name: Krishna reddy
Template URL: https://bootstrapmade.com/kelly-free-bootstrap-cv-resume-html-template/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
